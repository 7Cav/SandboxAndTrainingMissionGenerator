/* This file is for mission makers to set up Custom Loadouts for players.
   If you need help setting up the loadout vissit the link provided:
   https://github.com/BaerMitUmlaut/Poppy#creating-basic-loadouts
*/
