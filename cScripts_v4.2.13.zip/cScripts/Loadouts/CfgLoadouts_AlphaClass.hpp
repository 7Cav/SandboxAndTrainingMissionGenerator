//                A L P H A   C O M P A N Y

// Helo Crew

class B_Helipilot_F : CAV_Alpha_Helo_PILOT {};
//class undefinedClass : CAV_Alpha_Helo_COPILOT {};
class B_T_Helicrew_F : CAV_Alpha_Helo_CHIEF {};
class B_Helicrew_F : CAV_Alpha_Helo_GNR {};

//class undefinedClass : CAV_Alpha_Helo_PILOT_ATT {};
//class undefinedClass : CAV_Alpha_Helo_COPILOT_ATT {};

// Fixed-Wing

class B_Fighter_Pilot_F : CAV_Alpha_Fixed_PILOT {};