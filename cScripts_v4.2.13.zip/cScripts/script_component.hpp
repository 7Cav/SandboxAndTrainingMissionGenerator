#define PREFIX cScripts
#define VERSION "4.2.13"

// Uncomment to enable debug mode
//#define DEBUG_MODE

#include "script_macros.hpp"
