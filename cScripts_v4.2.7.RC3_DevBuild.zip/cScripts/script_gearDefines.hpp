//AMMONITION & GRENADES
#define _MAG_PRIMARY                rhs_mag_30Rnd_556x45_M855A1_Stanag
#define _MAG_PRIMARY_TRACER         rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Red
#define _MAG_AR0                    rhs_200rnd_556x45_M_SAW
#define _MAG_AR1                    rhsusf_100Rnd_762x51_m61_ap

#define _MAG_SNIPER0                rhsusf_5Rnd_300winmag_xm2010
#define _MAG_MARKSMAN0              ACE_20Rnd_762x51_Mk316_Mod_0_Mag
#define _MAG_MARKSMAN1              rhsusf_20Rnd_762x51_m118_special_Mag

#define _MAG_SECONDARY0              rhsusf_mag_15Rnd_9x19_JHP

#define _MAG_LAUNCHER0              rhs_fgm148_magazine_AT
#define _MAG_LAUNCHER1              rhs_fim92_mag
#define _MAG_LAUNCHER2              tf47_m3maaws_HEDP
#define _MAG_LAUNCHER3              tf47_m3maaws_HEAT
#define _MAG_LAUNCHER4              tf47_m3maaws_HE
#define _MAG_LAUNCHER5              tf47_m3maaws_SMOKE
#define _MAG_LAUNCHER6              tf47_m3maaws_ILLUM

#define _GRENADE                    rhs_mag_m67
#define _GRENADE_IR                 B_IR_Grenade
#define _GRENADE_SMOKE              SmokeShell
#define _GRENADE_SMOKE_RED          SmokeShellRed
#define _GRENADE_SMOKE_BLUE         SmokeShellBlue
#define _GRENADE_SMOKE_GREEN        SmokeShellGreen
#define _GRENADE_SMOKE_ORANGE       SmokeShellOrange
#define _GRENADE_SMOKE_YELLOW       SmokeShellYellow
#define _GRENADE_SMOKE_PURPLE       SmokeShellPurple

#define _GLSHELL0                   rhs_mag_M441_HE
#define _GLSHELL1                   rhs_mag_M433_HEDP
#define _GLSHELLSMOKE               rhs_mag_m714_White
#define _GLSHELLSMOKEGREEN          rhs_mag_m715_Green
#define _GLSHELLSMOKEYELLOW         rhs_mag_m716_yellow
#define _GLSHELLSMOKERED            rhs_mag_m713_Red
#define _GLSHELLHUNTIR              ACE_HUNTIR_M203
#define _GLFLARE                    rhs_mag_M585_white
