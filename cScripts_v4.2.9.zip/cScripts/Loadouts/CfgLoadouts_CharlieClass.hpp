//                C H A R L I E   C O M P A N Y

// Infantry
class rhsusf_army_ocp_arb_riflemanl : CAV_Charlie_OFFCR {};  // Use for all leadership positions from PSG up
class rhsusf_army_ocp_jfo : CAV_Charlie_JFO {}; // Joint Fires Observer
class rhsusf_army_ocp_arb_squadleader : CAV_Charlie_SL {};
class rhsusf_army_ocp_arb_teamleader : CAV_Charlie_TL {};
class rhsusf_army_ocp_arb_autorifleman : CAV_Charlie_AR {};
class rhsusf_army_ocp_arb_grenadier : CAV_Charlie_GR {};
class rhsusf_army_ocp_arb_rifleman : CAV_Charlie_RM {};
class rhsusf_army_ocp_arb_medic : CAV_Charlie_CLS {};

// Weapons - use for either HW or Mortars

class B_T_Soldier_SL_F : CAV_Charlie_Weapons_SL {};
class B_T_Soldier_TL_F : CAV_Charlie_Weapons_TL {};
class B_T_Engineer_F : CAV_Charlie_Weapons_AR {};
class B_T_Soldier_Repair_F : CAV_Charlie_Weapons_GR {};
class B_T_soldier_mine_F : CAV_Charlie_Weapons_RM {};
class B_T_Soldier_Exp_F : CAV_Charlie_Weapons_CLS {};
