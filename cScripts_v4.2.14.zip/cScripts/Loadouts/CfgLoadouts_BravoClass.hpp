//                B R A V O   C O M P A N Y

// Officers and Crew

class rhsusf_army_ocp_officer : CAV_Bravo_OFFCR {};
class rhsusf_army_ocp_combatcrewman : CAV_Bravo_Crew_CDR {};
class rhsusf_army_ocp_crewman : CAV_Bravo_Crew_GNR {};
class rhsusf_army_ocp_driver : CAV_Bravo_Crew_CREW {};

// Infantry

class rhsusf_army_ocp_squadleader : CAV_Bravo_SL {};
class rhsusf_army_ocp_teamleader : CAV_Bravo_TL {};
class rhsusf_army_ocp_autorifleman : CAV_Bravo_AR {};
class rhsusf_army_ocp_grenadier : CAV_Bravo_GR {};
class rhsusf_army_ocp_rifleman : CAV_Bravo_RM {};
class rhsusf_army_ocp_medic : CAV_Bravo_CLS {};

// Heavy Weapons

class rhsusf_army_ocp_machinegunnera : CAV_Bravo_Weapons_TL {};
class rhsusf_army_ocp_machinegunner : CAV_Bravo_Weapons_MG {};
class rhsusf_army_ocp_javelin : CAV_Bravo_Weapons_GNR {};
