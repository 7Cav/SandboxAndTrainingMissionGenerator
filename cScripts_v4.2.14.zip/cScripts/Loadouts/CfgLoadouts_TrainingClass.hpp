//                S 3   T R A I N I N G

// Instructors

class rhsusf_usmc_marpat_wd_officer : CAV_SOI_INSTR {};
class rhsusf_usmc_marpat_d_officer : CAV_JM_INSTR {};
class rhsusf_usmc_marpat_wd_crewman : CAV_TAS_INSTR {};
class rhsusf_usmc_marpat_wd_helipilot : CAV_ACE_ROTARY_INSTR {};
class rhsusf_airforce_jetpilot : CAV_ACE_FIXED_INSTR {};

// Students

class rhsusf_usmc_marpat_wd_rifleman_m4 : CAV_SOI_STUD {};
class rhsusf_usmc_marpat_wd_combatcrewman : CAV_TAS_STUD {};
class rhsusf_usmc_marpat_wd_helicrew : CAV_ACE_ROTARY_STUD {};
class rhsusf_airforce_pilot : CAV_ACE_FIXED_STUD {};
