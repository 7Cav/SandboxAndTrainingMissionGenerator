#define PREFIX cScripts
#define VERSION "4.3.6"

// Uncomment to enable debug mode
//#define DEBUG_MODE

#include "script_macros.hpp"
